"""WebSocket server that broadcasts stable gesture labels detected by hand_gestures.py

Usage:
    pip install websockets
    python gesture_ws_server.py

Clients can connect to ws://127.0.0.1:8765 and will receive JSON messages like:
    {"type":"gesture","label":"Hello"}

This server runs the detector in a background thread and schedules broadcasts on the asyncio loop.
"""
import asyncio
import json
import signal
import threading
from websockets import serve
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

from hand_gestures import run_headless

CLIENTS = set()

async def broadcast(msg):
    if not CLIENTS:
        return
    websockets = list(CLIENTS)
    try:
        await asyncio.gather(*[ws.send(msg) for ws in websockets], return_exceptions=True)
        print(f'broadcasted to {len(websockets)} client(s):', msg)
    except Exception as e:
        print('broadcast error:', e)

def make_on_gesture(loop):
    def on_gesture(label):
        print('detected label (server):', label)
        payload = json.dumps({"type":"gesture","label":label})
        # schedule broadcast on asyncio loop
        asyncio.run_coroutine_threadsafe(broadcast(payload), loop)
    return on_gesture


def start_test_http_server(on_gesture, host='127.0.0.1', port=8766):
    """Start a small HTTP server in a thread that accepts GET /broadcast?label=..."""
    class TestHandler(BaseHTTPRequestHandler):
        def do_GET(self):
            parsed = urlparse(self.path)
            if parsed.path != '/broadcast':
                self.send_response(404)
                self.end_headers()
                self.wfile.write(b'Not found')
                return
            qs = parse_qs(parsed.query)
            label = qs.get('label', [''])[0]
            if not label:
                self.send_response(400)
                self.end_headers()
                self.wfile.write(b'missing label')
                return
            try:
                on_gesture(label)
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({'status':'ok','label':label}).encode())
            except Exception as e:
                self.send_response(500)
                self.end_headers()
                self.wfile.write(str(e).encode())

        def log_message(self, format, *args):
            # quiet logs
            return

    server = ThreadingHTTPServer((host, port), TestHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    print(f'Test HTTP server listening on http://{host}:{port}/broadcast?label=...')
    return server

async def handler(ws, path):
    CLIENTS.add(ws)
    try:
        # simple welcome
        await ws.send(json.dumps({"type":"hello","msg":"connected"}))
        await ws.wait_closed()
    finally:
        CLIENTS.discard(ws)

async def main_async():
    loop = asyncio.get_running_loop()
    on_gesture = make_on_gesture(loop)

    stop_event = threading.Event()

    # start detector thread (it will call on_gesture which schedules coroutines on the running loop)
    detector_thread = threading.Thread(target=lambda: run_headless(on_gesture, camera_index=0, stability_seconds=3, stop_event=stop_event), daemon=True)
    detector_thread.start()

    server = await serve(handler, '127.0.0.1', 8765)
    print('WebSocket server running on ws://127.0.0.1:8765 — waiting for clients...')

    try:
        # Wait forever until cancelled (Ctrl+C)
        await asyncio.Future()
    except KeyboardInterrupt:
        print('Shutting down (keyboard interrupt)...')
    finally:
        stop_event.set()
        server.close()
        await server.wait_closed()


def main():
    try:
        asyncio.run(main_async())
    except KeyboardInterrupt:
        pass


if __name__ == '__main__':
    main()
