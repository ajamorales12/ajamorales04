# Messenger Landing Page

This is a simple static landing page for your Messenger app.

Files added:

- `index.html` — main landing page
- `styles.css` — styles
- `script.js` — small interactive script (form handling, smooth scroll)
- `logo.svg` — simple logo

This project now contains a minimal Messenger-style web app (chat UI only).

Files and purpose:

- `index.html` — Messenger GUI: sidebar, chat area, and message input.
- `styles.css` — styling for the chat UI.
- `script.js` — client-side logic: local message send/receive simulation.

How to run locally (PowerShell):

```powershell
# from project root
& "C:/Users/Lejeune Daseco/AppData/Local/Programs/Python/Python310/python.exe" -m http.server 8000
# then open the page
ii http://localhost:8000/index.html
```

Notes and next steps:

- The app no longer includes the camera/gesture panel. If you want it restored, I can re-add it or integrate a client-side recognition pipeline.
- The `Use Detected` button and detected-sign placeholder were removed.
- Authentication and backend messaging are not implemented — messages are stored in-memory for demo only.

Opening or running the `hand_gestures.py` script from the UI

- The camera button (left of the message input) now attempts to open the local file `C:/AppdevPro/hand_gestures.py` using a `file:///` URL. Some browsers block pages served over `http://` from opening `file://` URLs for security reasons; if that happens you'll see a fallback alert with the exact PowerShell command to run the script locally.

PowerShell command to run the script manually:

```powershell
& "C:/Users/Lejeune Daseco/AppData/Local/Programs/Python/Python310/python.exe" "C:/AppdevPro/hand_gestures.py"
```

If you want the UI to execute the Python script directly (no manual step), I can add a small local backend endpoint (a Python HTTP server) that will run the script when the page requests it. Note that running local scripts from the browser has security implications and requires you to start the server on your machine; tell me if you want me to implement that and I will add instructions and the server code.

Local run server (added):

1. Start the local run server (this runs `run_server.py`) in PowerShell from the project folder:

```powershell
& "C:/Users/Lejeune Daseco/AppData/Local/Programs/Python/Python310/python.exe" run_server.py
```

2. With the server running on `http://127.0.0.1:5000`, clicking the camera button will POST to `/run-script` and the server will execute `hand_gestures.py`. The server returns stdout/stderr as JSON which the UI displays in an alert.

Security note: The server will execute the local Python script with the same privileges as the user who started the server. Only run this on a trusted machine and avoid exposing the server to remote networks.

WebSocket server (reuse Python detector):

If you prefer to reuse the Python `hand_gestures.py` detector and stream detections into the browser (recommended to avoid running heavy client-side models), a small WebSocket bridge is included: `gesture_ws_server.py`.

1. Install the Python dependency:

```powershell
& "C:/Users/Lejeune Daseco/AppData/Local/Programs/Python/Python310/python.exe" -m pip install websockets
```

2. Run the WebSocket server (this will start the headless detector and broadcast stable gestures):

```powershell
& "C:/Users/Lejeune Daseco/AppData/Local/Programs/Python/Python310/python.exe" gesture_ws_server.py
```

3. Open the UI (served or file) and it will automatically try connecting to `ws://127.0.0.1:8765`. When the Python detector observes a gesture consistently for ~3 seconds, the server will push a JSON message to the page and the UI will insert the gesture into the message input.

Notes:
- Make sure your webcam is free (not used by another app) since the detector opens the camera.
- The WebSocket server binds to `127.0.0.1` only for safety. Do not expose this to untrusted networks.

How to open locally (PowerShell):

```powershell
# from project root
ii .\index.html
```

Or open `index.html` in your browser directly.

Next steps:

- Replace copy, colors, and logo with your branding.
- Hook the contact form to your backend / mailing service.
- Provide download links or platform build artifacts.
