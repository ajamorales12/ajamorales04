"""
Simple hand gesture recognizer using MediaPipe + OpenCV.
Works well on Python 3.10.

Recognized gestures (heuristic mappings):
 - Hello (open palm / all fingers up)
 - Goodbye (fist / no fingers up)
 - Yes (thumbs up)
 - Peace (V sign: index + middle up)
 - I Am (pointing with index)
 - Other mapped signs: Thank You, Please, Sorry, Help, No (heuristic examples)

Usage:
    python hand_gestures.py
Press 'q' to quit.
"""

import cv2
import mediapipe as mp
import math
from collections import Counter

mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils

# Which landmarks are finger tips and pip (for comparisons)
FINGER_TIPS = [4, 8, 12, 16, 20]    # thumb, index, middle, ring, pinky tips
FINGER_PIPS =  [2, 6, 10, 14, 18]   # approximate PIP or similar joint for comparison

def vector_angle(a, b, c):
    """Return angle ABC in degrees (useful if needed)."""
    ab = (a[0]-b[0], a[1]-b[1])
    cb = (c[0]-b[0], c[1]-b[1])
    dot = ab[0]*cb[0] + ab[1]*cb[1]
    mag = math.hypot(*ab) * math.hypot(*cb)
    if mag == 0:
        return 0.0
    cosang = max(-1, min(1, dot/mag))
    return math.degrees(math.acos(cosang))

def fingers_up(hand_landmarks, handedness):
    """
    Determine which fingers are up.
    Returns list of 5 booleans: [thumb, index, middle, ring, pinky]
    handedness: 'Left' or 'Right' - affects thumb logic
    """
    lm = hand_landmarks.landmark
    h = [ (l.x, l.y, l.z) for l in lm ]  # normalized coords

    fingers = []
    # Thumb: compare tip and ip/x positions horizontally depending on hand
    # For camera mirrored view, use x comparisons: for right hand, tip x < ip x when thumb is open (might vary)
    thumb_tip_x = h[FINGER_TIPS[0]][0]
    thumb_ip_x  = h[FINGER_PIPS[0]][0]

    if handedness == 'Right':
        # right hand: thumb pointing left in camera when extended -> tip x < ip x
        thumb_is_open = thumb_tip_x < thumb_ip_x - 0.02
    else:
        # left hand: thumb pointing right when extended -> tip x > ip x
        thumb_is_open = thumb_tip_x > thumb_ip_x + 0.02

    fingers.append(thumb_is_open)

    # Other fingers: tip y lower (smaller) than pip y when finger is up (camera coords)
    for tip_i, pip_i in zip(FINGER_TIPS[1:], FINGER_PIPS[1:]):
        tip_y = h[tip_i][1]
        pip_y = h[pip_i][1]
        # if tip is sufficiently above pip -> finger up
        fingers.append(tip_y < pip_y - 0.01)

    return fingers

def classify_gesture(fingers):
    """
    Map fingers list to gesture name.
    fingers: [thumb, index, middle, ring, pinky]
    """
    t, i, m, r, p = fingers
    pattern = tuple(bool(x) for x in fingers)

    # Exact pattern map (you can extend this mapping):
    PATTERN_MAP = {
        (True, True, True, True, True): 'Hello',        # open palm
        (False, False, False, False, False): 'Goodbye', # fist
        (True, False, False, False, False): 'Yes',       # thumbs up
        (False, True, True, False, False): 'Peace',     # V sign
        (False, True, False, False, False): 'I Am',     # pointing / index
        (False, True, False, False, True): 'Thank You', # custom heuristic
        (False, True, True, True, True): 'Please',      # custom heuristic
        (False, False, False, False, True): 'Sorry',    # pinky only -> example
        (True, False, False, False, True): 'Call Me',   # thumb + pinky (shaka-like)
        (False, True, False, True, False): 'Help',      # index + ring -> example
        (False, True, False, True, True): 'No',         # example
    }

    if pattern in PATTERN_MAP:
        return PATTERN_MAP[pattern]

    # Fallback heuristics
    up_count = sum(fingers)
    if up_count == 5:
        return 'Hello'
    if up_count == 0:
        return 'Goodbye'
    if t and not any([i, m, r, p]):
        return 'Yes'
    if i and m and not any([t, r, p]):
        return 'Peace'
    if i and not any([t, m, r, p]):
        return 'I Am'

    return 'Unknown'

def main():
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("ERROR: Could not open webcam. If you have multiple cameras, change index in VideoCapture(0).")
        return

    with mp_hands.Hands(
        static_image_mode=False,
        max_num_hands=2,
        min_detection_confidence=0.6,
        min_tracking_confidence=0.5
    ) as hands:

        while True:
            ret, frame = cap.read()
            if not ret:
                break

            # Flip for mirror view (so left/right feel natural)
            frame = cv2.flip(frame, 1)
            h, w, _ = frame.shape
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

            results = hands.process(rgb)

            gesture_text = ""
            if results.multi_hand_landmarks:
                # If multiple hands, classify each and show aggregated result
                labels = []
                for hand_landmarks, handedness in zip(results.multi_hand_landmarks, results.multi_handedness):
                    # handedness.classification[0].label -> 'Left' or 'Right'
                    hand_label = handedness.classification[0].label
                    fingers = fingers_up(hand_landmarks, hand_label)
                    gesture = classify_gesture(fingers)
                    labels.append(gesture)

                    # draw landmarks
                    mp_drawing.draw_landmarks(
                        frame, hand_landmarks, mp_hands.HAND_CONNECTIONS,
                        mp_drawing.DrawingSpec(color=(0,255,0), thickness=2, circle_radius=3),
                        mp_drawing.DrawingSpec(color=(255,0,0), thickness=2)
                    )

                # choose most common label if multiple hands
                gesture_text = Counter(labels).most_common(1)[0][0]

            # Display text
            cv2.rectangle(frame, (0,0), (300,40), (0,0,0), -1)
            cv2.putText(frame, f'Gesture: {gesture_text}', (10,25),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255,255,255), 2)

            cv2.imshow("Hand Gesture", frame)
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()


def run_headless(broadcast_callback, camera_index=0, stability_seconds=3, stop_event=None):
    """
    Run the gesture detector without any GUI. Calls `broadcast_callback(label)` whenever
    a stable label has been observed for `stability_seconds` seconds.

    - broadcast_callback: callable(label:str) -> None
    - camera_index: int camera device index (default 0)
    - stability_seconds: float seconds required to consider detection stable
    - stop_event: optional threading.Event used to request stop from outside
    """
    import time
    import threading

    cap = cv2.VideoCapture(camera_index)
    if not cap.isOpened():
        raise RuntimeError('Could not open webcam (index: {})'.format(camera_index))

    last_label = None
    detect_start = 0

    with mp_hands.Hands(
        static_image_mode=False,
        max_num_hands=2,
        min_detection_confidence=0.6,
        min_tracking_confidence=0.5
    ) as hands:

        try:
            while True:
                if stop_event and getattr(stop_event, 'is_set', lambda: False)():
                    break

                ret, frame = cap.read()
                if not ret:
                    time.sleep(0.01)
                    continue

                # mirror for natural left/right
                frame = cv2.flip(frame, 1)
                rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

                results = hands.process(rgb)

                gesture_text = None
                if results.multi_hand_landmarks:
                    labels = []
                    for hand_landmarks, handedness in zip(results.multi_hand_landmarks, results.multi_handedness):
                        hand_label = handedness.classification[0].label
                        fingers = fingers_up(hand_landmarks, hand_label)
                        gesture = classify_gesture(fingers)
                        labels.append(gesture)

                    gesture_text = Counter(labels).most_common(1)[0][0]
                else:
                    gesture_text = None

                now = time.time()
                if gesture_text and gesture_text == last_label:
                    # continue timing
                    if detect_start == 0:
                        detect_start = now
                    elif (now - detect_start) >= float(stability_seconds):
                        try:
                            broadcast_callback(gesture_text)
                        except Exception:
                            pass
                        # reset, avoid immediate repeated sends
                        last_label = None
                        detect_start = 0
                else:
                    last_label = gesture_text
                    detect_start = now if gesture_text else 0

                # slight sleep to yield CPU
                time.sleep(0.01)
        finally:
            cap.release()

