import asyncio
import websockets

async def main():
    uri = 'ws://127.0.0.1:8765'
    try:
        async with websockets.connect(uri) as ws:
            print('connected to', uri)
            # wait for one message (welcome or gesture)
            try:
                msg = await asyncio.wait_for(ws.recv(), timeout=10.0)
                print('received:', msg)
            except asyncio.TimeoutError:
                print('no message received in 10s')
    except Exception as e:
        print('ws client error:', e)

if __name__ == '__main__':
    asyncio.run(main())
