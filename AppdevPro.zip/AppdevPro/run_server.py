#!/usr/bin/env python3
"""
Small local server to run `hand_gestures.py` on demand.

Usage:
    python run_server.py

This starts a server on http://localhost:5000 with a POST /run-script endpoint.
It runs the local `hand_gestures.py` with the same Python interpreter and returns
stdout/stderr as JSON. This is intended for local development only.
"""
import http.server
import socketserver
import subprocess
import sys
import os
import json

PORT = 5000

class Handler(http.server.BaseHTTPRequestHandler):
    def _set_cors_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')

    def do_OPTIONS(self):
        self.send_response(200)
        self._set_cors_headers()
        self.end_headers()

    def do_POST(self):
        if self.path != '/run-script':
            self.send_response(404)
            self._set_cors_headers()
            self.end_headers()
            return

        script_path = os.path.join(os.path.dirname(__file__), 'hand_gestures.py')
        resp = {'status': 'error', 'stdout': '', 'stderr': ''}
        try:
            # Run script using same Python interpreter that started the server
            proc = subprocess.run([sys.executable, script_path], capture_output=True, text=True, timeout=60)
            resp['status'] = 'ok' if proc.returncode == 0 else f'returncode:{proc.returncode}'
            resp['stdout'] = proc.stdout
            resp['stderr'] = proc.stderr
        except Exception as e:
            resp['status'] = 'exception'
            resp['stderr'] = str(e)

        body = json.dumps(resp).encode('utf-8')
        self.send_response(200)
        self._set_cors_headers()
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

if __name__ == '__main__':
    print(f'Starting local run server on http://localhost:{PORT} (CTRL+C to stop)')
    with socketserver.TCPServer(('127.0.0.1', PORT), Handler) as httpd:
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print('\nStopping server')
            httpd.server_close()
