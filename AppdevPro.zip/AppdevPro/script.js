// Basic UI script: message handling only (camera/gesture removed)
document.addEventListener('DOMContentLoaded', function(){
  // Set copyright year if present
  const yearEl = document.getElementById('year');
  if(yearEl) yearEl.textContent = new Date().getFullYear();

  // Simulated chat storage + rendering
  let messages = [];
  function renderMessages(){
    const container = document.getElementById('messages');
    if(!container) return;
    container.innerHTML = '';
    messages.forEach(m=>{
      const el = document.createElement('div');
      el.className = 'message' + (m.me? ' me':'');
      if(m.meta){
        const meta = document.createElement('div'); meta.className='meta'; meta.textContent = m.meta; el.appendChild(meta);
      }
      const body = document.createElement('div'); body.className='body'; body.textContent = m.text; el.appendChild(body);
      container.appendChild(el);
    });
    container.scrollTop = container.scrollHeight;
  }

  const msgForm = document.getElementById('messageForm');
  const msgInput = document.getElementById('messageInput');
  if(msgForm){
    msgForm.addEventListener('submit', function(e){
      e.preventDefault();
      const text = (msgInput.value||'').trim();
      if(!text) return;
      messages.push({text,me:true,meta:'You'});
      renderMessages();
      msgInput.value = '';
      // Simulate reply
      setTimeout(()=>{ messages.push({text:'(auto-reply) Received: '+text,me:false,meta:'Bot'}); renderMessages(); },700);
    });
  }

  // Contact form handler (if present)
  const form = document.getElementById('contactForm');
  if(form){
    form.addEventListener('submit', function(e){
      e.preventDefault();
      const email = (document.getElementById('email')||{}).value || '';
      if(!email || !email.includes('@')){ alert('Please provide a valid email address.'); return; }
      alert('Thanks! We will notify ' + email + ' when we launch.');
      form.reset();
    });
  }

  // Login handler (if present)
  const loginForm = document.getElementById('loginForm');
  if(loginForm){
    loginForm.addEventListener('submit', function(e){
      e.preventDefault();
      const email = (document.getElementById('loginEmail')||{}).value || '';
      const password = (document.getElementById('loginPassword')||{}).value || '';
      if(!email || !email.includes('@')){ alert('Enter a valid email.'); return; }
      if(!password || password.length < 4){ alert('Enter a valid password.'); return; }
      alert('Demo login successful for ' + email + ' (no backend connected).');
      loginForm.reset();
    });
  }

  renderMessages();
  // Gesture item click -> insert text into input
  const gestureList = document.getElementById('gestureList');
  if(gestureList){
    gestureList.addEventListener('click', function(e){
      const li = e.target.closest('.gesture-item');
      if(!li) return;
      const text = li.textContent.trim();
      const input = document.getElementById('messageInput');
      if(input){
        input.value = text;
        input.focus();
      }
    });
  }
  // Camera toggle for inline preview
  const cameraBtn = document.getElementById('cameraBtn');
  const cameraContainer = document.getElementById('cameraContainer');
  const inlineVideo = document.getElementById('inlineVideo');
  let _inlineStream = null;
  // MediaPipe hands variables
  let handsDetector = null;
  let _mpRunning = false;
  let lastDetected = null;
  let detectStart = 0;
  let detectTriggered = false;

  async function startInlineCamera(){
    if(!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia){
      alert('Camera API not available in this browser.');
      return;
    }
    try{
      _inlineStream = await navigator.mediaDevices.getUserMedia({video:{width:640},audio:false});
      if(inlineVideo) inlineVideo.srcObject = _inlineStream;
      if(cameraContainer) cameraContainer.style.display = 'block';
      cameraBtn.textContent = '⏹';

      // Initialize MediaPipe Hands detector if available
      if(typeof Hands !== 'undefined' && !handsDetector){
        handsDetector = new Hands({locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`});
        handsDetector.setOptions({
          maxNumHands: 2,
          modelComplexity: 1,
          minDetectionConfidence: 0.6,
          minTrackingConfidence: 0.5
        });
        handsDetector.onResults(onMpResults);
      }

      // start processing frames
      _mpRunning = true;
      const processFrame = async () => {
        if(!_mpRunning) return;
        if(handsDetector && inlineVideo.readyState >= 2){
          try{ await handsDetector.send({image: inlineVideo}); }catch(e){/*ignore*/}
        }
        requestAnimationFrame(processFrame);
      };
      requestAnimationFrame(processFrame);
    }catch(err){
      console.error('Camera error', err);
      alert('Could not access camera: ' + (err.message||err));
    }
  }

  function stopInlineCamera(){
    if(_inlineStream){
      _inlineStream.getTracks().forEach(t=>t.stop());
      _inlineStream = null;
    }
    if(inlineVideo) inlineVideo.srcObject = null;
    if(cameraContainer) cameraContainer.style.display = 'none';
    if(cameraBtn) cameraBtn.textContent = '📷';
    // stop MediaPipe processing
    _mpRunning = false;
    // reset detection state
    lastDetected = null; detectStart = 0; detectTriggered = false;
    const detectedTextEl = document.getElementById('detectedLiveText');
    if(detectedTextEl) detectedTextEl.textContent = '—';
  }

  if(cameraBtn){
    cameraBtn.addEventListener('click', async function(){
      // Call local server endpoint to run the script. Make sure the local server is running.
      const serverUrl = 'http://127.0.0.1:5000/run-script';
      try{
        const resp = await fetch(serverUrl, {method:'POST'});
        if(!resp.ok){
          throw new Error('Server responded with ' + resp.status);
        }
        const data = await resp.json();
        const out = (data.stdout||'').trim();
        const err = (data.stderr||'').trim();
        const status = data.status || 'unknown';
        const summary = `run-script status: ${status}\nstdout:\n${out || '(none)'}\n\nstderr:\n${err || '(none)'}`;
        // show the result (trim long output)
        alert(summary.slice(0, 4000));
      }catch(e){
        console.error('Could not call run server', e);
        alert('Could not contact local run server at http://127.0.0.1:5000.\nStart it with: python run_server.py\n\nError: '+ e.message);
      }

      // Keep inline camera behavior as before (toggle preview)
      if(_inlineStream) stopInlineCamera(); else startInlineCamera();
    });
  }
  
  // Helper: determine fingers up from Mediapipe landmarks
  function fingersUpFromLandmarks(landmarks, handednessLabel){
    // landmarks: array of {x,y,z}
    const tips = [4,8,12,16,20];
    const pips = [2,6,10,14,18];
    const h = landmarks.map(l => [l.x, l.y, l.z]);
    const fingers = [];
    // thumb
    const thumb_tip_x = h[tips[0]][0];
    const thumb_ip_x  = h[pips[0]][0];
    let thumb_is_open = false;
    if(handednessLabel === 'Right'){
      thumb_is_open = thumb_tip_x < thumb_ip_x - 0.02;
    }else{
      thumb_is_open = thumb_tip_x > thumb_ip_x + 0.02;
    }
    fingers.push(thumb_is_open);
    // other fingers by y
    for(let k=1;k<tips.length;k++){
      const tip_y = h[tips[k]][1];
      const pip_y = h[pips[k]][1];
      fingers.push(tip_y < pip_y - 0.01);
    }
    return fingers;
  }

  // Pattern map same as Python
  const PATTERN_MAP = {
    '1,1,1,1,1': 'Hello',
    '0,0,0,0,0': 'Goodbye',
    '1,0,0,0,0': 'Yes',
    '0,1,1,0,0': 'Peace',
    '0,1,0,0,0': 'I Am',
    '0,1,0,0,1': 'Thank You',
    '0,1,1,1,1': 'Please',
    '0,0,0,0,1': 'Sorry',
    '1,0,0,0,1': 'Call Me',
    '0,1,0,1,0': 'Help',
    '0,1,0,1,1': 'No'
  };

  // Called by MediaPipe hands on results
  function onMpResults(results){
    let detected = '—';
    if(results.multiHandLandmarks && results.multiHandLandmarks.length){
      const labels = [];
      for(let i=0;i<results.multiHandLandmarks.length;i++){
        const lm = results.multiHandLandmarks[i];
        const handed = (results.multiHandedness && results.multiHandedness[i] && results.multiHandedness[i].label) || 'Right';
        const fingers = fingersUpFromLandmarks(lm, handed);
        const key = fingers.map(x=> x?1:0).join(',');
        const name = PATTERN_MAP[key] || (fingers.reduce((s,val)=>s+(val?1:0),0)===5? 'Hello' : (fingers.reduce((s,val)=>s+(val?1:0),0)===0? 'Goodbye':'Unknown'));
        labels.push(name);
      }
      // take most common
      const counts = {};
      labels.forEach(l=> counts[l] = (counts[l]||0)+1);
      detected = Object.keys(counts).reduce((a,b)=> counts[a]>=counts[b]?a:b);
    }

    // update UI
    const detectedTextEl = document.getElementById('detectedLiveText');
    if(detectedTextEl) detectedTextEl.textContent = detected;

    // detection persistence: if same detected for >=3s, insert into input
    const now = Date.now();
    if(detected === lastDetected){
      if(!detectStart) detectStart = now;
      if(!detectTriggered && (now - detectStart) >= 3000){
        // insert into input
        const input = document.getElementById('messageInput');
        if(input && detected && detected !== '—' && detected !== 'Unknown'){
          input.value = detected;
          input.focus();
          detectTriggered = true;
        }
      }
    }else{
      lastDetected = detected;
      detectStart = now;
      detectTriggered = false;
    }
  }

    // WebSocket client to receive server-side detections (optional). If a server
    // is running at ws://127.0.0.1:8765 it will send JSON {type:'gesture',label:'...'}
    try{
      const ws = new WebSocket('ws://127.0.0.1:8765');
      ws.addEventListener('open', ()=>{ console.log('gesture WS connected'); });
      ws.addEventListener('message', (ev)=>{
        try{
          const data = JSON.parse(ev.data);
          if(data && data.type === 'gesture' && data.label){
            const detectedTextEl = document.getElementById('detectedLiveText');
            if(detectedTextEl) detectedTextEl.textContent = data.label;
            const input = document.getElementById('messageInput');
            if(input){ input.value = data.label; input.focus(); }
          }
        }catch(e){ console.warn('Invalid WS message', e); }
      });
      ws.addEventListener('close', ()=>{ console.log('gesture WS closed'); });
      ws.addEventListener('error', (e)=>{ console.warn('gesture WS error', e); });
    }catch(e){ /* ignore if browser doesn't allow WS */ }
});
